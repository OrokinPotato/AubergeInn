drop table if exists "Auberge-Inn"."CommoditesChambres";

