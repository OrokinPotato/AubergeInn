drop table if exists "Auberge-Inn"."Chambres";

