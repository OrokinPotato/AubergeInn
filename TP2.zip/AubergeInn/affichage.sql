SELECT * FROM Commodites;
SELECT * FROM CommoditesChambres;
SELECT * FROM Reservations;
SELECT * FROM Clients;
SELECT * FROM Chambres;